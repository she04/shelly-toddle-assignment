import React from 'react';
import './App.css';
import Add from './Component/Add';

const App = () => {
  

  return (
    <div className='m'>
      <div className="m1">
        Course Builder
      </div>
      <div className="m2">
      <Add/>
      </div>
      
    </div>
  );
};

export default App;
